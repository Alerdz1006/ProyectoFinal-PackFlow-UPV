<?php
namespace App\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Firebase\JWT\JWT;
use PDO;

class AuthController {
    private $db;
    private $key = "tu_clave_secreta_upv_2026"; // Esta clave debe ser la misma en todos tus microservicios

    public function __construct(PDO $db) {
        $this->db = $db;
    }

    public function login(Request $request, Response $response) {
        // Obtenemos los datos del JSON enviado
        $data = $request->getParsedBody();
        $correo = $data['correo'] ?? '';
        $password = $data['password'] ?? '';

        try {
            // 1. Buscar al usuario por correo
            $stmt = $this->db->prepare("SELECT id, nombre, correo, password FROM usuarios WHERE correo = :correo");
            $stmt->execute(['correo' => $correo]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            // 2. Verificar si el usuario existe y la contraseña coincide
            // Nota: En producción usa password_verify() con hashes, aquí usamos texto plano por simplicidad académica
            if ($user && $password === $user['password']) {
                
                // 3. Crear el Payload del Token
                $payload = [
                    'iss' => 'sistema-paqueteria-upv', // Emisor
                    'iat' => time(),                   // Fecha de creación
                    'exp' => time() + (60 * 60 * 24),  // Expira en 24 horas
                    'data' => [                        // Datos del usuario
                        'id' => $user['id'],
                        'nombre' => $user['nombre'],
                        'correo' => $user['correo']
                    ]
                ];

                // 4. Generar el JWT
                $jwt = JWT::encode($payload, $this->key, 'HS256');

                $result = [
                    'status' => 'success',
                    'message' => 'Login exitoso',
                    'token' => $jwt,
                    'user' => [
                        'nombre' => $user['nombre'],
                        'correo' => $user['correo']
                    ]
                ];

                $response->getBody()->write(json_encode($result));
                return $response
                    ->withHeader('Content-Type', 'application/json')
                    ->withStatus(200);
            }

            // Si las credenciales no coinciden
            $response->getBody()->write(json_encode([
                'status' => 'error',
                'message' => 'Correo o contraseña incorrectos'
            ]));
            return $response
                ->withHeader('Content-Type', 'application/json')
                ->withStatus(401);

        } catch (\Exception $e) {
            // Manejo de errores de base de datos o sistema
            $response->getBody()->write(json_encode([
                'status' => 'error',
                'message' => 'Error interno en el servidor: ' . $e->getMessage()
            ]));
            return $response
                ->withHeader('Content-Type', 'application/json')
                ->withStatus(500);
        }
    }
}
