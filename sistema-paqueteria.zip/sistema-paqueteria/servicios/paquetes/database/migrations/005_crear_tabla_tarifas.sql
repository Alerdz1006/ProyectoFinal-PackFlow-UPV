-- Tabla para definir precios por rango de peso y zona
CREATE TABLE tarifas_envio (
    id SERIAL PRIMARY KEY,
    zona_id INTEGER NOT NULL,
    peso_min DECIMAL(10,2) NOT NULL,
    peso_max DECIMAL(10,2) NOT NULL,
    precio_base DECIMAL(10,2) NOT NULL, -- Lo que cuesta el envío en ese rango
    precio_kg_extra DECIMAL(10,2) DEFAULT 0, -- Por si se pasa del peso_max
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Datos de ejemplo iniciales (Seeds)
INSERT INTO tarifas_envio (zona_id, peso_min, peso_max, precio_base) VALUES 
(1, 0.00, 5.00, 15.00),  -- Zona Local, hasta 5kg: $15
(1, 5.01, 10.00, 25.00), -- Zona Local, 5-10kg: $25
(2, 0.00, 5.00, 35.00);  -- Zona Nacional, hasta 5kg: $35
