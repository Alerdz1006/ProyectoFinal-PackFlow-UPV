<?php
use Slim\Factory\AppFactory;
use DI\ContainerBuilder;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

require __DIR__ . '/../vendor/autoload.php';

// 1. Configuración del Contenedor de Dependencias (PHP-DI)
$containerBuilder = new ContainerBuilder();

$containerBuilder->addDefinitions([
    PDO::class => function () {
        $host = 'db';
        $db   = 'paqueteria_db';
        $user = 'alejandro';
        $pass = 'password';
        $dsn = "pgsql:host=$host;port=5432;dbname=$db;";
        
        return new PDO($dsn, $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
    },
]);

// 2. Crear la App con el contenedor
AppFactory::setContainer($containerBuilder->build());
$app = AppFactory::create();

// 3. Middleware para parsear JSON en el cuerpo de las peticiones
$app->addBodyParsingMiddleware();

// 4. Middleware de CORS (Vital para que el Frontend se conecte)
$app->add(function (Request $request, $handler) {
    $response = $handler->handle($request);
    return $response
        ->withHeader('Access-Control-Allow-Origin', '*')
        ->withHeader('Access-Control-Allow-Headers', 'X-Requested-With, Content-Type, Accept, Origin, Authorization')
        ->withHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS')
        ->withHeader('Access-Control-Allow-Credentials', 'true');
});

// 5. Manejo de peticiones OPTIONS (Pre-flight)
$app->options('/{routes:.+}', function ($request, $response) {
    return $response;
});

// 6. Cargar las rutas
require __DIR__ . '/../routes/api.php';

$app->run();
