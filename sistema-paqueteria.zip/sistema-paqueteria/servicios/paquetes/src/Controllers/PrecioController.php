<?php
namespace App\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use App\Calculadora\CalculadoraPrecio;

class PrecioController {
    public function calcular(Request $request, Response $response) {
        $data = $request->getParsedBody();
        
        $calc = new CalculadoraPrecio();
        
        $resultado = $calc->calcular(
            (float)($data['peso'] ?? 0),
            (float)($data['largo'] ?? 0),
            (float)($data['ancho'] ?? 0),
            (float)($data['alto'] ?? 0),
            (int)($data['zona_id'] ?? 1)
        );

        $response->getBody()->write(json_encode($resultado));
        return $response->withHeader('Content-Type', 'application/json');
    }
}
