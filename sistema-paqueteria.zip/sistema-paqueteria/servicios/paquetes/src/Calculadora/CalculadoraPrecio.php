<?php
namespace App\Calculadora;

use PDO;

class CalculadoraPrecio {
    private $db;

    public function __construct() {
        $config = require __DIR__ . '/../../config/database.php';
        $dsn = "pgsql:host={$config['host']};dbname={$config['database']}";
        $this->db = new PDO($dsn, $config['username'], $config['password'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]);
    }

    public function calcular(float $peso, float $largo, float $ancho, float $alto, int $zonaId) {
        $pesoVolumetrico = ($largo * $ancho * $alto) / 5000;
        $pesoFinal = max($peso, $pesoVolumetrico);

        // Buscar la tarifa en la DB según la zona y el peso
        $stmt = $this->db->prepare("
            SELECT precio_base FROM tarifas_envio 
            WHERE zona_id = :zona 
            AND :peso BETWEEN peso_min AND peso_max
            LIMIT 1
        ");
        
        $stmt->execute(['zona' => $zonaId, 'peso' => $pesoFinal]);
        $tarifa = $stmt->fetch();

        $total = $tarifa ? $tarifa['precio_base'] : ($pesoFinal * 10); // Default si no hay rango

        return [
            'peso_facturable' => $pesoFinal,
            'total' => round($total, 2),
            'metodo' => $tarifa ? 'Tarifa por Tabla' : 'Tarifa por Defecto (Kg)'
        ];
    }
}
