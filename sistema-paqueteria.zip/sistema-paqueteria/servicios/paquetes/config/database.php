<?php
// servicios/paquetes/config/database.php
return [
    'host' => 'db', // Nombre del servicio en docker-compose
    'database' => 'paqueteria_db',
    'username' => 'alejandro',
    'password' => 'password',
];
