<?php
use Slim\Routing\RouteCollectorProxy;
use App\Controllers\PrecioController;
use App\Controllers\AuthController; // <-- IMPORTANTE

$app->post('/api/v1/login', [AuthController::class, 'login']);

$app->group('/api/v1', function (RouteCollectorProxy $group) {
    $group->post('/calcular-precio', [PrecioController::class, 'calcular']);
});
