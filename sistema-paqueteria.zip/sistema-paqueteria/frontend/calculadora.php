<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculadora de Envío | Sistema Paquetería</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@picocss/pico@1/css/pico.min.css">
    <style>
        :root { --primary: #2563eb; }
        body { padding-top: 2rem; background-color: #f8fafc; }
        main { max-width: 800px; }
        #resultado { margin-top: 2rem; border-left: 5px solid var(--primary); display: none; }
    </style>
</head>
<body class="container">
    <header>
        <nav>
            <ul><li><strong>Paquetería</strong></li></ul>
        </nav>
    </header>

    <main>
        <hgroup>
            <h2>Calculadora de Tarifas</h2>
            <h3>Cotiza tus envíos nacionales al instante</h3>
        </hgroup>

        <form id="calcForm">
            <div class="grid">
                <label>Peso Real (kg)
                    <input type="number" name="peso" step="0.01" placeholder="Ej: 2.5" required>
                </label>
                <label>Zona de Destino
                    <select name="zona_id" required>
                        <option value="1">Zona 1 (Local)</option>
                        <option value="2">Zona 2 (Nacional)</option>
                    </select>
                </label>
            </div>
            <details>
                <summary>Dimensiones (cm)</summary>
                <div class="grid">
                    <label>Largo <input type="number" name="largo" value="10"></label>
                    <label>Ancho <input type="number" name="ancho" value="10"></label>
                    <label>Alto <input type="number" name="alto" value="10"></label>
                </div>
            </details>
            <button type="submit" id="btnCalcular">Calcular Costo de Envío</button>
        </form>

        <article id="resultado">
            <header>✅ Cotización Generada</header>
            <div class="grid">
                <div>
                    <p>Total a pagar:</p>
                    <h2 id="totalPrecio" style="color: var(--primary);">$0.00</h2>
                </div>
                <div id="detalleEnvio" style="align-self: center;"></div>
            </div>
        </article>
    </main>

    <script>
        document.getElementById('calcForm').onsubmit = async (e) => {
            e.preventDefault();
            const btn = document.getElementById('btnCalcular');
            btn.ariaBusy = "true";

            const data = Object.fromEntries(new FormData(e.target));

            try {
                // Usamos 127.0.0.1 para evitar bloqueos de red local
                const response = await fetch('http://127.0.0.1:8081/api/v1/calcular-precio', {
                    method: 'POST',
                    mode: 'cors',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });

                if (!response.ok) throw new Error("Error en el servicio");

                const res = await response.json();
                document.getElementById('resultado').style.display = 'block';
                document.getElementById('totalPrecio').innerText = `$${res.total} USD`;
                document.getElementById('detalleEnvio').innerHTML = 
                    `<strong>Peso:</strong> ${res.peso_facturable} kg<br><strong>Método:</strong> ${res.metodo}`;
            } catch (error) {
                alert("Error de conexión con la API. Revisa el CORS.");
            } finally {
                btn.ariaBusy = "false";
            }
        };
    </script>
</body>
</html>
